#ifndef _CLUSTER_H_
#define _CLUSTER_H_
#include "data.h"

static const uint nbCluster=10;


float distEuclid(float a,float b);

int minItem(double dist_x[], int n);











#endif //_CLUSTER_H_
